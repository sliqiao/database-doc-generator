# stu_self_ans(stu_self_ans)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|id|int8||否|null|
|user_id|int8||否|null|
|test_id|int8||否|null|
|que_id|int8||否|null|
|state|int2||否|1:未掌握 2：已掌握|
|create_time|timestamp||否|null|
