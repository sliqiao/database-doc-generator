# exam_report_region_joint(exam_report_region_joint)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|id|int8||否|null|
|act_id|int8||否|null|
|create_time|timestamp||否|null|
|max_score|numeric||否|null|
|min_score|numeric||否|null|
|param_code|varchar||否|null|
|param_value|varchar||否|null|
|reg_code|varchar||否|null|
|score|numeric||否|null|
|sort|int4||否|null|
|stu_num|int4||否|null|
