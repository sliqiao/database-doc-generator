# 这个考试的考点分布(exam_place_distr)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|test_id|int8||否|null|
|place_id|int8||否|null|
|update_time|timestamp||否|null|
