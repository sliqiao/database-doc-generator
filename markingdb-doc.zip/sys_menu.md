# sys_menu(sys_menu)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|menu_id|int8||否|null|
|menu_url|varchar||否|null|
|menu_name|varchar||否|null|
|sup_menu_id|int8||否|null|
|is_leaf|int4||否|1为叶子菜单|
|sort|int4||否|null|
|level|int4||否|null|
|time_update|timestamp||否|null|
