# tiku_paper(tiku_paper)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|id|int8||是|null|
|title|varchar||是|null|
|subject_id|int4||是|null|
|province_id|int4||是|null|
|year|int4||是|null|
|type_id|int4||是|null|
|level_id|int4||是|null|
|grade_id|int4||是|null|
|string_ids|text||是|null|
|date|timestamp||是|null|
