# exam_role(exam_role)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|role_id|int8||否|null|
|role_name|varchar||否|null|
|role_desc|varchar||否|null|
|status|int4||否|null|
|update_time|timestamp||否|null|
