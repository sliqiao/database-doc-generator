# zj_question_category_12(zj_question_category_12)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|id|int8||否|null|
|question_zu_juan_id|int8||是|null|
|subject_zu_juan_id|int8||是|null|
|type_id|int8||是|null|
|type|int8||是|null|
|path_ids|varchar||是|null|
