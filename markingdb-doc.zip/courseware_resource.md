# courseware_resource(courseware_resource)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|id|int8||否|null|
|courseware_id|int8||否|null|
|rec_id|varchar||是|null|
|status|int2||否|null|
|insert_time|timestamp||是|null|
|delete_time|timestamp||是|null|
|courseware_content|varchar||是|null|
