# que_attr_bak(que_attr_bak)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|attr_id|int8||是|null|
|attr_code|varchar||是|null|
|name|varchar||是|null|
|name_cn|varchar||是|null|
|name_short|varchar||是|null|
|attr_up|int8||是|null|
|lev|int4||是|null|
|sort_no|int4||是|null|
|attr_type|int8||是|null|
|org_id|int8||是|null|
|subject|int8||是|null|
|key_stage|int8||是|null|
|user_create|int8||是|null|
|status|int4||是|null|
|time_update|timestamp||是|null|
|remark|varchar||是|null|
|grade|int8||是|null|
|term|int8||是|null|
