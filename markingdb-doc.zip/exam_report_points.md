# exam_report_points(exam_report_points)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|id|int8||否|null|
|test_id|int8||是|null|
|pap_id|int8||是|null|
|que_id|int8||是|null|
|que_type|int8||是|null|
|stu_id|int8||是|null|
|ans_id|int8||是|null|
|point_id|int8||是|null|
|point_name|varchar||是|null|
|score|numeric||是|null|
|pap_score|numeric||是|null|
|create_time|timestamp||是|null|
