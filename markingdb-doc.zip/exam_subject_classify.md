# 比如主副科、文理科的，也包括每个年级有那些科目，先不考虑地区之间的差异(exam_subject_classify)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|subject_id|int8||否|null|
|dir_id|int8||否|null|
|update_time|timestamp||否|null|
