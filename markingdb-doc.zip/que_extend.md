# 托福的短文音频、图片音频、题目音频、准备音频、答题音频也保存在这里，只保存资源id(que_extend)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|ext_id|int8||否|null|
|busi_id|int8||否|null|
|ext_key|int8||否|null|
|ext_value|varchar||否|null|
|sort_no|int4||否|这里指同一个属性有多个值，他们间的排序，默认为1|
|time_update|timestamp||否|null|
