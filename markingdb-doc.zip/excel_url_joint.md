# excel_url_joint(excel_url_joint)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|id|int8||否|null|
|name|varchar||否|null|
|act_id|int8||否|null|
|reg_code|varchar||否|null|
|create_time|timestamp||否|null|
|url|varchar||否|null|
