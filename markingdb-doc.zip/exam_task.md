# exam_task(exam_task)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|task_id|int8||否|null|
|ans_id|int8||是|null|
|img_id|int8||是|null|
