# 一个题目可以有多个图片(exam_que_pic)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|que_pic_id|int8||否|null|
|pap_page_id|int8||否|null|
|que_id|int8||否|null|
|top_x|int4||否|null|
|top_y|int4||否|null|
|bottom_x|int4||否|null|
|bottom_y|int4||否|null|
|pic_type|int8||否|题目、解析等，见《系统编码》117001题目  117002解析
|
|res_id|int8||否|null|
|sort_no|int4||否|null|
|operator|int8||否|null|
|time_update|timestamp||否|null|
