# tiku(tiku)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|id|int8||否|null|
|diff_id|int4||是|null|
|type_id|int4||是|null|
|paper_id|int4||是|null|
|title|varchar||是|null|
|body|text||是|null|
|answer|text||是|null|
|analysis|text||是|null|
|date|timestamp||是|null|
