# 每个模考都填写(wk_section)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|wk_id|int8||否|null|
|sec_id|int8||否|null|
|user_id|int8||否|null|
|pap_id|int8||是|null|
|time_start|timestamp||否|null|
|time_end|timestamp||否|null|
|len_sec|int4||否|做题时间秒|
|num_que|int4||否|null|
|num_not|int4||否|null|
|num_right|int4||否|null|
|num_wrong|int4||否|null|
|time_update|timestamp||否|null|
