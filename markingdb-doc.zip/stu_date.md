# stu_date(stu_date)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|year|int8||是|null|
|schoolname|int8||是|null|
|grade|varchar||是|null|
|class|varchar||是|null|
|classid|int8||是|null|
|subject_type|varchar||是|null|
|nosid|int4||是|null|
|sid|int8||否|null|
|name|varchar||是|null|
