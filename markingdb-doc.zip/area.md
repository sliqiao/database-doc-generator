# area(area)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|id|int8||是|null|
|parentid|int8||是|null|
|name|varchar||是|null|
|level|int4||是|null|
|first|bpchar||是|null|
|ismunicipality|int4||是|null|
|hasschool|int4||是|null|
