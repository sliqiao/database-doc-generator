# eer_student_word(eer_student_word)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|id|int8||否|null|
|student_id|int8||是|null|
|word_id|int8||是|null|
|create_date|timestamp||是|首次记单词的时间|
|end_date|timestamp||是|null|
