# exam_correct_record(exam_correct_record)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|record_id|int8||否|null|
|que_id|int8||否|null|
|wk_que_id|int8||否|null|
|check_seq|int4||否|null|
|tech_id|int8||否|null|
|arbitration|int4||否|null|
|update_time|timestamp||否|null|
|score|numeric||否|null|
|test_id|int8||否|null|
|marking_sort|int4||是|null|
|que_group_id|int8||是|题块id|
