# tk_que_attr_bak(tk_que_attr_bak)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|qa_id|int8||是|null|
|attr_id|int8||是|null|
|que_id|int8||是|null|
|dift|int8||是|null|
|time_create|timestamp||是|null|
