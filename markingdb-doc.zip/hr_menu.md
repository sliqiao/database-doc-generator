# hr_menu(hr_menu)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|menu_id|varchar||否|菜单编号|
|up_id|varchar||否|上级菜单编号|
|menu_name|varchar||否|菜单名称|
|sub_id|varchar||否|节点编号|
|lev|int4||否|级别|
|sort|int4||否|排序|
|status|int4||否|状态：1正常、0停用|
