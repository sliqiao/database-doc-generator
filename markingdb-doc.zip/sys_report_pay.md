# 记录报告(sys_report_pay)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|pay_id|int8||否|null|
|pay_id_in|varchar||否|null|
|pay_account|varchar||否|null|
|test_id|int8||否|null|
|user_id|int8||否|null|
|pay_money|numeric||否|null|
|pay_status|int4||否|0-未支付 1-已支付
|
|update_time|timestamp||否|null|
