# exam_article_info(exam_article_info)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|article_id|int8||否|主键|
|grade_id|int8||是|年级id|
|create_time|timestamp||否|创建时间|
|file_path|varchar||是|文件路径|
