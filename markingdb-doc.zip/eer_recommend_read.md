# eer_recommend_read(eer_recommend_read)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|id|int8||否|null|
|article_name|varchar||是|文章名称|
|article_image_url|varchar||是|文章对应图片url|
|article_body|text||是|文章正文|
|create_time|timestamp||是|null|
|update_time|timestamp||是|null|
|del_flag|int2||是|null|
|create_user|int8||是|null|
