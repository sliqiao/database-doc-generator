# temp_que_type(temp_que_type)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|id|int8||否|null|
|type_name|varchar||否|null|
|type_code|varchar||否|null|
