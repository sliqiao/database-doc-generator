# tk_que_a_bak(tk_que_a_bak)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|que_code|varchar||是|null|
|que_id|int8||是|null|
|que_type|int8||是|null|
|type_name|varchar||是|null|
|que_ability|int8||是|null|
|ability_name|varchar||是|null|
|que_dift|int8||是|null|
|dift_name|varchar||是|null|
|time_create|timestamp||是|null|
|title|text||是|null|
|answer|text||是|null|
|analysis|text||是|null|
|sub_id|int8||是|null|
|que_types|int8||是|null|
|que_type_a|int8||是|null|
|sub_id_a|int8||是|null|
