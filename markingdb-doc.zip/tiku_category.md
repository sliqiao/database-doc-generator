# tiku_category(tiku_category)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|cid|int8||是|null|
|subject_id|int4||是|null|
|parent_id|int8||是|null|
|type|varchar||是|null|
|name|varchar||是|null|
|depth|int4||是|null|
|list_order|int8||是|null|
|xkw_id|int8||是|null|
