# exam_report_stu(exam_report_stu)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|id|int8||否|null|
|stu_id|int8||是|null|
|test_id|int8||否|null|
|param_code|varchar||否|null|
|param_value|varchar||否|null|
|score|numeric||否|null|
|sort|int4||否|null|
|class_sort|int4||是|null|
|grade_sort|int4||是|null|
|create_time|timestamp||否|null|
|stand_score|numeric||否|null|
