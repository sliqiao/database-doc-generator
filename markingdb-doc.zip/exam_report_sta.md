# exam_report_sta(exam_report_sta)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|id|int8||否|null|
|test_id|int8||是|null|
|pap_id|int8||是|null|
|stu_entry_num|int8||是|null|
|stu_join_num|int8||是|null|
|stu_unjoin_num|int8||是|null|
|score|numeric||是|null|
|max_score|numeric||是|null|
|min_score|numeric||是|null|
|average_score|numeric||是|null|
|median_score|numeric||是|null|
|modeno_score|numeric||是|null|
|create_time|timestamp||是|null|
