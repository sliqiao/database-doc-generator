# exam_audit(exam_audit)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|id|int8||否|null|
|op_id|int8||否|null|
|url|varchar||否|null|
|source_ip|varchar||否|null|
|content|varchar||否|超过300截断|
|update_time|timestamp||否|null|
