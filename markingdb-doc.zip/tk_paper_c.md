# tk_paper_c(tk_paper_c)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|pap_id|int8||否|null|
|site_id|int8||否|null|
|pap_code|varchar||否|null|
|pap_name|varchar||否|null|
|pap_type|int8||否|null|
|score|int8||否|null|
|grade_type|int8||否|null|
|term_type|int8||否|null|
|reg_prov|varchar||否|null|
|reg_city|varchar||否|null|
|reg_county|varchar||否|null|
|remark|varchar||否|null|
|time_publish|timestamp||否|null|
|time_update|timestamp||否|null|
|time_create|timestamp||否|null|
|type|int4||是|null|
|textbook_id|int8||是|null|
|subject|_int8||是|null|
