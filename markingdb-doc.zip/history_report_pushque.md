# history_report_pushque(history_report_pushque)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|report_id|int8||否|null|
|history_report_id|int8||否|null|
|class_id|int8||否|null|
|class_name|varchar||否|null|
|subject_id|int8||否|null|
|subject_name|varchar||否|null|
|school_id|int8||否|null|
|school_name|varchar||否|null|
|grade_id|int8||否|null|
|grade_name|varchar||否|null|
|stu_id|int8||否|null|
|stu_name|varchar||否|null|
|create_time|timestamp||否|null|
|report_que_path|varchar||是|null|
|report_answer_path|varchar||是|null|
|report_path|varchar||是|null|
|kpoint_num|int4||否|null|
|ques_num|int4||否|null|
|que_attrs|text||否|null|
|ques|text||否|null|
|start_time|timestamp||否|null|
|end_time|timestamp||否|null|
|status|bpchar||否|null|
|ticket_no|varchar||是|null|
|report_head_path|varchar||是|null|
|report_foot_path|varchar||是|null|
