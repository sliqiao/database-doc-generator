# 一个考试，可以分为多次小考试，比如上午、下午，语、数、外等，用来列出这次考试可选的试卷(exam_test_detail)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|spec_test_id|int8||否|null|
|parent_test_id|int8||否|null|
|spec_test_name|varchar||否|null|
|pap_id|int8||否|允许采用多个试卷|
|begin_time|timestamp||否|null|
|end_time|timestamp||否|null|
|update_time|timestamp||否|null|
|solioquy|varchar||是|null|
|so_res_id|int8||是|null|
