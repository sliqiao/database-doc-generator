# 一个试卷可以有多个图片(exam_paper_pic)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|pap_page_id|int8||否|null|
|pap_id|int8||否|null|
|sort_no|int4||否|null|
|res_id|int8||否|null|
|operator|int8||否|null|
|time_update|timestamp||否|null|
