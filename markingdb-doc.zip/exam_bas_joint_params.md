# exam_bas_joint_params(exam_bas_joint_params)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|id|int8||否|null|
|act_id|int8||否|null|
|create_time|timestamp||否|null|
|param_code|varchar||否|null|
|param_name|varchar||否|null|
|param_value|varchar||否|null|
