# 科目不考虑上下级(exam_subject)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|subject_id|int8||否|null|
|subject_code|varchar||否|null|
|subject_name|varchar||否|null|
|status|int4||否|null|
|sort_no|numeric||否|null|
|update_time|timestamp||否|null|
|stage|int8||是|null|
