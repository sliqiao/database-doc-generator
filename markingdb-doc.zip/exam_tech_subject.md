# 记录每个老师教的科目(exam_tech_subject)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|tech_id|int8||否|null|
|subject_id|int8||否|null|
|grade|int8||否|null|
|update_time|timestamp||否|null|
