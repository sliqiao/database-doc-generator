# 出版物的章节属性(exam_publication_attr)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|attr_id|int8||否|null|
|textbook_attr_id|int8||否|null|
|chapter_name|varchar||否|null|
|su_id|int8||否|null|
|update_time|timestamp||否|null|
