# essay_valid_t(essay_valid_t)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|prediction_id|int8||否|null|
|essay_id|int8||是|null|
|essay_set|int8||是|null|
|essay_weight|numeric||是|null|
|predicted_score|int4||是|null|
