# stu_pdf_url(stu_pdf_url)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|id|int8||否|null|
|stu_id|int8||否|null|
|act_id|int8||否|null|
|status|int4||否|null|
|update_time|timestamp||否|null|
|url|varchar||是|null|
|check_status|int4||是|null|
