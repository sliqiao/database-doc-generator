# advert_school(advert_school)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|id|int8||否|null|
|address|varchar||是|null|
|area|varchar||是|null|
|before_last_year_arts_alignment|varchar||是|null|
|before_last_year_arts_average_rank|varchar||是|null|
|before_last_year_arts_rank|varchar||是|null|
|before_last_year_science_alignment|varchar||是|null|
|before_last_year_science_average_rank|varchar||是|null|
|before_last_year_science_rank|varchar||是|null|
|code|varchar||否|null|
|cooperation|int4||否|null|
|honor|varchar||是|null|
|last_year_arts_alignment|varchar||是|null|
|last_year_arts_average_rank|varchar||是|null|
|last_year_arts_rank|varchar||是|null|
|last_year_science_alignment|varchar||是|null|
|last_year_science_average_rank|varchar||是|null|
|last_year_science_rank|varchar||是|null|
|logo_url|varchar||是|null|
|name|varchar||否|null|
|office_url|varchar||是|null|
|student_url|varchar||是|null|
|tel|varchar||是|null|
|web_href|varchar||是|null|
|create_time|timestamp||是|null|
