# temp_grade_subject(temp_grade_subject)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|id|int8||否|null|
|grade_id|int4||否|null|
|subject_id|int4||否|null|
|exam_subject_id|int8||否|null|
|parse_id|int4||否|null|
|exam_grade_id|int8||否|null|
