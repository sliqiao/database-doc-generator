# tk_paper_exam(tk_paper_exam)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|id|int8||否|试卷绑多答题卡中间表|
|pap_id|int8||是|null|
|create_time|timestamp||是|null|
|exam_name|varchar||是|null|
|sheet_name|varchar||是|null|
|exam_id|int8||是|null|
|sheet_id|int8||是|null|
