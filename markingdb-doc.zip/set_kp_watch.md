# set_kp_watch(set_kp_watch)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|id|int8||否|null|
|user_id|int8||否|null|
|attr_id|int8||否|null|
|watch|int2||是|null|
|create_time|timestamp||是|null|
|type|int2||是|1是知识点,2是题目|
|test_id|int8||是|null|
|pap_id|int8||是|null|
