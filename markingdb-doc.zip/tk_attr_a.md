# tk_attr_a(tk_attr_a)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|attr_code|int8||是|null|
|name|varchar||是|null|
|attr_id|int8||否|null|
|sub_id|int8||是|null|
|parent_id|int8||是|null|
|attr_type|int8||是|null|
|path_ids|varchar||是|null|
