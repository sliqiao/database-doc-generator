# zj_paper(zj_paper)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|id|int8||否|null|
|paper_zu_juan_id|int8||否|null|
|title|varchar||是|null|
|subject_zu_juan_id|int8||是|null|
|learn_grade_id|int8||是|null|
|learn_grade_name|varchar||是|null|
|learn_grade_paper_type_list|varchar||是|null|
|paper_type_id|int8||是|null|
|paper_type_name|varchar||是|null|
|province_id|int8||是|null|
|province_name|varchar||是|null|
|province_short_name|varchar||是|null|
|paper_year_id|int8||是|null|
|paper_year_name|varchar||是|null|
|time|timestamp||否|null|
|paper_ques_count|int8||否|null|
