# delay_task(delay_task)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|id|int8||否|null|
|message|varchar||否|消息内容|
|state|int4||否|消息状态|
|start_time|int8||否|开始时间|
|create_time|timestamp||是|创建时间|
