# tk_que_d(tk_que_d)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|que_id|int8||否|null|
|site_id|int8||否|null|
|que_code|varchar||否|null|
|que_type|int8||否|null|
|que_types|int8||否|null|
|sub_id|int8||否|null|
|title|text||否|null|
|num_option|int8||否|null|
|answer_img|varchar||否|null|
|answer|text||否|null|
|analysis_img|varchar||否|null|
|analysis|text||否|null|
|que_up|int8||否|null|
|sort_up|int8||否|null|
|dift|int8||否|null|
|belong_org|int8||否|null|
|belong_user|int8||否|null|
|rule|varchar||否|null|
|audit_user|int8||否|null|
|audit_time|timestamp||否|null|
|audit_status|int8||否|null|
|status|int8||否|null|
|remark|varchar||否|null|
|time_update|timestamp||否|null|
|time_create|timestamp||否|null|
|grade|int4||否|null|
