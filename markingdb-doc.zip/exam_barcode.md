# 记录每次考试的条码信息(exam_barcode)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|barcode_id|int8||否|null|
|place_id|int8||否|null|
|room_id|int8||否|null|
|seat_no|int4||否|null|
|ticket_no|varchar||否|null|
|stu_id|int8||否|null|
|test_id|int8||否|null|
|sheet_id|int8||否|null|
|create_time|timestamp||是|null|
