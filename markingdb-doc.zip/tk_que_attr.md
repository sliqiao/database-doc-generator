# 题目属性关系(tk_que_attr)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|qa_id|int8||否|关系ID|
|attr_id|int8||否|属性ID|
|que_id|int8||否|题目ID|
|dift|int8||否|难度【枚举】：0未定义、1容易、3普通、5困难|
|time_create|timestamp||否|创建时间|
