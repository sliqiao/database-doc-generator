# courseware(courseware)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|id|int8||否|null|
|courseware_name|varchar||否|null|
|attr_id|int8||否|null|
|status|int2||否|null|
|create_time|timestamp||是|null|
|update_time|timestamp||是|null|
