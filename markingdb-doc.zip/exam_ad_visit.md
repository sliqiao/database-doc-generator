# exam_ad_visit(exam_ad_visit)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|id|int8||否|null|
|visit_id|varchar||否|null|
|visit_ip|varchar||否|null|
|visit_url|varchar||否|null|
|visit_time|timestamp||否|null|
