# tk_paper_que_d(tk_paper_que_d)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|pq_id|int8||否|null|
|pap_id|int8||否|null|
|que_id|int8||否|null|
|pq_type|int8||否|null|
|score|numeric||否|null|
|desp|varchar||否|null|
|tree_path|varchar||否|null|
|tree_up|int8||否|null|
|tree_lev|int8||否|null|
|tree_sort|int8||否|null|
