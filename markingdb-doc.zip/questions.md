# questions(questions)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|id|int8||否|null|
|title|text||是|null|
|option_a|text||是|null|
|option_b|text||是|null|
|option_c|text||是|null|
|option_d|text||是|null|
|option_e|text||是|null|
|answer1|text||是|null|
|answer2|text||是|null|
|parse|text||是|null|
|qtpye|varchar||是|null|
|diff|numeric||是|null|
|md5|varchar||是|null|
|subjectid|int4||是|null|
|gradeid|int4||是|null|
|knowledges|varchar||是|null|
|area|varchar||是|null|
|year|int4||是|null|
|papertpye|varchar||是|null|
|source|varchar||是|null|
|fromsite|varchar||是|null|
|issub|int4||是|null|
|isnormal|int4||是|null|
|iskonw|int4||是|null|
|tiid|varchar||是|null|
|similarity|int8||是|null|
