# 记录看报告时候的广告设置(ad_report_conf)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|test_id|int8||否|null|
|subject_ids|varchar||否|采用字符串类型，允许多个学科|
|ad_url|varchar||否|null|
|score_b|numeric||否|null|
|score_e|numeric||否|null|
|time_update|timestamp||是|null|
