# eer_wrong_words(eer_wrong_words)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|id|int8||否|null|
|word_id|int8||是|null|
|counts|int8||是|错误次数|
