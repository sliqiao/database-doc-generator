# temp_scan_status(temp_scan_status)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|wk_sheet_id|varchar||是|null|
|status|int4||是|null|
|update_time|varchar||是|null|
|stuId|varchar||是|null|
