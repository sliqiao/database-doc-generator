# 记录无法识别的自定义答题卡(exam_unknown_pic)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|id|int8||否|null|
|test_id|int8||否|null|
|sheet_id|int8||否|null|
|place_id|int8||否|null|
|res_ids|varchar||否|null|
|status|int4||是|null|
|update_time|timestamp||否|null|
