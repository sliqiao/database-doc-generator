# tk_que_opts_d(tk_que_opts_d)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|opts_id|int8||否|null|
|que_id|int8||否|null|
|sort|int8||否|null|
|opts_code|varchar||否|null|
|opts_txt|text||否|null|
