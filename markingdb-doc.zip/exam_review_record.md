# 记录双评的历史(exam_review_record)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|region_id|int8||否|null|
|current_times|int4||否|null|
|noted_times|int4||否|null|
|teacher_a|int8||否|null|
|score_a|numeric||否|null|
|teacher_b|int8||否|null|
|score_b|numeric||否|null|
|score_ar|numeric||否|null|
|arbitrators|int8||否|null|
|update_time|timestamp||否|null|
