# zj_subject(zj_subject)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|id|int8||否|null|
|name|varchar||是|null|
|full_name|varchar||是|null|
|school_phase_id|int4||是|null|
|subject_zu_juan_id|int8||是|null|
