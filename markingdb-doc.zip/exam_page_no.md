# 由于page_Id在生成图片时候并没有生成，这里改为查询条码时候，先生成(exam_page_no)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|page_id|int8||否|null|
|sheet_id|int8||否|null|
|page_no|int4||否|null|
|time_update|timestamp||否|null|
