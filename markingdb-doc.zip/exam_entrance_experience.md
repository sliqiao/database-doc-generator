# 记录学生的入学记录(exam_entrance_experience)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|entrance_id|int8||否|null|
|stu_id|int8||否|null|
|year|int4||否|null|
|half_year|int4||否|null|
|grade|int8||否|null|
|class_id|int8||否|null|
|school_id|int8||否|null|
|update_time|timestamp||否|null|
|seat_no|int8||是|null|
|ticket_no|varchar||是|null|
|source|int4||是|null|
