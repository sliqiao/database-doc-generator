# zj_question_26(zj_question_26)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|id|int8||否|null|
|question_zu_juan_id|int8||是|null|
|question_type_id|int8||是|null|
|question_type_name|varchar||是|null|
|ability_id|int8||是|null|
|ability_name|varchar||是|null|
|question_different_id|int8||是|null|
|question_different_name|varchar||是|null|
|time|timestamp||否|null|
|question_body|text||否|null|
|question_answer|text||是|null|
|question_parse|text||是|null|
|is_download|int8||是|null|
|subject|int8||是|null|
