# tk_que_attr_a(tk_que_attr_a)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|qa_id|int8||否|null|
|que_id|int8||是|null|
|sub_id|int8||是|null|
|attr_id|int8||是|null|
|type|int4||是|1表示知识点，2表示章节，3表示试卷|
|path_ids|varchar||是|null|
