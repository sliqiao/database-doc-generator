# tk_report_error(tk_report_error)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|id|int8||否|null|
|que_id|int8||否|null|
|time_create|timestamp||否|null|
|time_update|timestamp||是|null|
|mistake_type|_int8||是|null|
|status|int4||是|null|
