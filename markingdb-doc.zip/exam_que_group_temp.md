# exam_que_group_temp(exam_que_group_temp)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|id|int8||是|null|
|group_name|varchar||是|null|
|questions|_int8||是|null|
|is_merger_score|int4||是|null|
|creator|int8||是|null|
|create_time|timestamp||是|null|
|test_id|int8||是|null|
|pap_id|int8||是|null|
|subject_id|int8||是|null|
|sort_no|int4||是|null|
