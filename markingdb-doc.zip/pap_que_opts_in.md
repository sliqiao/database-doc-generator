# pap_que_opts_in(pap_que_opts_in)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|pqo_id|int8||否|null|
|pq_id|int8||否|null|
|sort|int8||否|null|
|opts_code|varchar||否|null|
|opts_txt|text||否|null|
