# que_paper_que(que_paper_que)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|pq_id|int8||否|试卷题目ID|
|pap_id|int8||否|试卷ID|
|sec_id|int8||否|题型ID|
|que_id|int8||否|题目ID：只存小题ID|
|que_up|int8||否|上级题目ID|
|que_type|int8||否|题型|
|sort_sec|int8||否|题型排序|
|sort_pap|int8||否|试卷排序|
|time_update|timestamp||否|更新时间|
