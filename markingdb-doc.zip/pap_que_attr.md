# 试卷题目属性关系(pap_que_attr)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|pqa_id|int8||否|关系ID|
|attr_id|int8||否|属性ID|
|pq_id|int8||否|题目ID|
