# que_answer(que_answer)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|ans_id|int8||否|选项ID|
|que_id|int8||否|题目ID|
|sort_no|int4||否|排序|
|content|varchar||是|内容|
|content_cn|varchar||是|内容中文|
|num_file|int4||是|附件数量|
|time_update|timestamp||是|更新时间|
