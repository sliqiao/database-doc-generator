# exam_review_conf(exam_review_conf)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|que_id|int8||否|null|
|test_id|int8||否|null|
|paper_id|int8||否|null|
|count|int4||否|null|
|arbitrators|int8||否|null|
|error_value|numeric||否|null|
|update_time|timestamp||否|null|
|arbitrators2|_int8||是|null|
