# tk_que_attr_d(tk_que_attr_d)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|qa_id|int8||否|null|
|attr_id|int8||否|null|
|que_id|int8||否|null|
|dift|int8||否|null|
|time_create|timestamp||否|null|
