# 指定这次考试的阅卷老师，如果老师不阅这次卷，则可以删除(exam_test_tech)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|id|int8||否|null|
|test_id|int8||否|null|
|pap_id|int8||是|null|
|tech_id|int8||否|null|
|update_time|timestamp||否|null|
|sub_code|int8||是|null|
