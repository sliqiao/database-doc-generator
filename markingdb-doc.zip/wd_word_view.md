# wd_word_view(wd_word_view)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|wid|varchar||是|null|
|word|varchar||是|null|
|phonetica|varchar||是|null|
|audioa|varchar||是|null|
|phonetice|varchar||是|null|
|audioe|varchar||是|null|
|status|varchar||是|null|
|time_create|varchar||是|null|
|time_update|varchar||是|null|
