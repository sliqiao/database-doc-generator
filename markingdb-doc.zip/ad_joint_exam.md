# ad_joint_exam(ad_joint_exam)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|ad_id|int8||否|null|
|res_id|varchar||是|null|
|pic_url|varchar||是|null|
|ad_location|varchar||是|null|
|ad_url|varchar||是|null|
|create_time|timestamp||是|null|
|update_time|timestamp||是|null|
