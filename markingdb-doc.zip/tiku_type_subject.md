# tiku_type_subject(tiku_type_subject)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|id|int8||是|null|
|tiku_type_id|int8||否|null|
|subject_id|int8||否|null|
