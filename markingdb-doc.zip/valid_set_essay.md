# valid_set_essay(valid_set_essay)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|essay_id|int8||否|null|
|essay_set|int4||是|null|
|essay|varchar||是|null|
|domain1_predictionid|int8||是|null|
|domain2_predictionid|int8||是|null|
