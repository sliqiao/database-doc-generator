# 记录微信绑定的信息(sys_user_bind)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|bind_id|varchar||否|null|
|user_id|int8||否|null|
|mobile|varchar||是|null|
|status|int4||否|null|
|update_time|timestamp||是|null|
