# que_attr_busi_c(que_attr_busi_c)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|busi_id|int8||否|null|
|attr_id|int8||否|null|
|time_update|timestamp||是|null|
|zj_attr_id|int8||是|null|
