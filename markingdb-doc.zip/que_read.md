# que_read(que_read)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|read_id|int8||否|编号|
|title|varchar||否|阅读标题|
|note_head|varchar||否|阅读前注|
|note_below|varchar||否|阅读尾注|
|test_type|int8||否|考试类型|
|subject|int8||否|科目|
|num_art|int4||否|文章数量|
|time_update|timestamp||否|更新时间|
|up_id|int8||否|null|
|sort_no|int8||否|null|
