# exam_report_class_bak(exam_report_class_bak)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|id|int8||是|null|
|class_id|int8||是|null|
|grade|int8||是|null|
|school_id|int8||是|null|
|test_id|int8||是|null|
|param_code|varchar||是|null|
|param_value|varchar||是|null|
|score|numeric||是|null|
|stu_num|int4||是|null|
|sort|int4||是|null|
|grade_sort|int4||是|null|
|max_score|numeric||是|null|
|min_score|numeric||是|null|
|create_time|timestamp||是|null|
