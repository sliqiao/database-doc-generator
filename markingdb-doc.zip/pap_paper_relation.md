# 组卷试卷辅助信息表(pap_paper_relation)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|id|int8||否|主键ID|
|pap_id|int8||否|组卷试卷id|
|pap_key|varchar||否|字段key|
|pap_value|varchar||否|字段value|
