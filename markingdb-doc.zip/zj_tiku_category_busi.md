# zj_tiku_category_busi(zj_tiku_category_busi)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|zj_attr_id|int8||是|null|
|tiku_attr_id|int8||是|null|
|create_time|date||是|null|
|attr_type|int8||是|null|
|zj_attr_up|int8||是|null|
|zj_attr_code|int8||是|null|
|tiku_attr_code|int8||是|null|
