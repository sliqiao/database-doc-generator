# exam_report_gov(exam_report_gov)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|id|int8||否|null|
|school_id|int8||否|null|
|test_id|int8||否|null|
|param_code|varchar||否|null|
|param_value|varchar||否|null|
|score|numeric||否|null|
|stu_num|int8||否|null|
|max_score|numeric||否|null|
|min_score|numeric||否|null|
|sort_no|int4||否|null|
|create_time|timestamp||否|null|
