# tk_que_opts_c(tk_que_opts_c)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|opts_id|int8||否|null|
|que_id|int8||否|null|
|sort|int8||否|null|
|opts_code|varchar||否|null|
|opts_txt|text||否|null|
