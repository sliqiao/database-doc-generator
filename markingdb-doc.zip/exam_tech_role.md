# 学生和家长的菜单是固定的，而老师是根据角色不同，显示不同的内容(exam_tech_role)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|tech_id|int8||否|null|
|role_id|int8||否|null|
|update_time|timestamp||否|null|
