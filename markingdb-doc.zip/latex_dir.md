# latex_dir(latex_dir)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|id|int8||否|null|
|tag|varchar||是|标签名称|
|latex|varchar||是|latex值|
|type|int4||是|类型 0.嵌入型 1.替换型|
