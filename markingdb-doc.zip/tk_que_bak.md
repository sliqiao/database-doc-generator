# tk_que_bak(tk_que_bak)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|que_id|int8||是|null|
|site_id|int8||是|null|
|que_code|varchar||是|null|
|que_type|int8||是|null|
|que_types|int8||是|null|
|sub_id|int8||是|null|
|title|text||是|null|
|num_option|int8||是|null|
|answer_img|varchar||是|null|
|answer|text||是|null|
|analysis_img|varchar||是|null|
|analysis|text||是|null|
|que_up|int8||是|null|
|sort_up|int8||是|null|
|dift|int8||是|null|
|belong_org|int8||是|null|
|belong_user|int8||是|null|
|rule|varchar||是|null|
|audit_user|int8||是|null|
|audit_time|timestamp||是|null|
|audit_status|int8||是|null|
|status|int8||是|null|
|remark|varchar||是|null|
|time_update|timestamp||是|null|
|time_create|timestamp||是|null|
|grade|int4||是|null|
