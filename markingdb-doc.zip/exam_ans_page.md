# 这个这需要把FileCenter也部署到新东方(exam_ans_page)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|page_id|int8||否|null|
|sheet_id|int8||否|null|
|page_no|int4||否|null|
|res_id|varchar||否|校正之后的图片资源|
|res_id_ori|varchar||否|null|
|top_x|int4||否|null|
|top_y|int4||否|null|
|bottom_x|int4||否|null|
|bottom_y|int4||否|null|
|length|int4||否|null|
|width|int4||否|null|
|update_time|timestamp||否|null|
