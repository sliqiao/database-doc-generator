# sys_role_menu(sys_role_menu)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|role_id|int8||否|null|
|menu_id|int8||否|null|
|time_update|timestamp||否|null|
