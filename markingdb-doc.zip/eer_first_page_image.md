# 首页轮播图(eer_first_page_image)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|id|int8||否|null|
|smaller_image_url|varchar||是|缩略图url|
|image_url|varchar||是|大图url|
|image_name|varchar||是|图片名称|
|create_time|timestamp||是|创建时间|
|update_time|timestamp||是|更新时间|
|del_flag|int2||是|null|
|create_user|int8||是|创建人id|
