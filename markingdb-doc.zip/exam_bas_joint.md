# exam_bas_joint(exam_bas_joint)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|act_id|int8||否|null|
|act_name|varchar||否|null|
|create_time|timestamp||否|null|
|creator|int8||否|null|
|status|int4||否|null|
|update_time|timestamp||否|null|
|test_id|_int8||否|null|
