# 2018-3-9修改(exam_img_deal)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|guid|varchar||否|null|
|res_id|varchar||否|图片编号|
|dir|varchar||是|null|
|sort_no|int4||是|null|
|mac|varchar||是|null|
|opeartor_id|int8||是|null|
|batch_no|varchar||是|null|
|test_id|int8||是|null|
|place_id|int8||是|null|
|sheet_id|int8||是|null|
|wk_page_id|int8||是|null|
|time_update|timestamp||否|修改时间|
