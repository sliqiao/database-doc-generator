# 填空题每region的空对应的所有位置信息(homework_que_position_tk)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|tk_ans_region_id|int8||否|主键，和tkansregion表ID一致|
|positions|varchar||是|位置信息，json|
|create_time|timestamp||否|null|
