# zj_paper_province(zj_paper_province)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|id|int8||否|null|
|paper_province_zu_juan_id|int8||是|null|
|name|varchar||否|null|
