# que_attr_c(que_attr_c)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|attr_id|int8||否|null|
|attr_code|varchar||否|null|
|name|varchar||否|null|
|name_cn|varchar||否|null|
|name_short|varchar||否|null|
|attr_up|int8||否|null|
|lev|int4||否|null|
|sort_no|int4||否|null|
|attr_type|int8||否|null|
|org_id|int8||否|null|
|subject|int8||否|null|
|key_stage|int8||否|null|
|user_create|int8||否|null|
|status|int4||否|null|
|time_update|timestamp||否|null|
|remark|varchar||否|null|
|grade|int8||是|null|
|term|int8||是|null|
|sys_code|int8||是|null|
