# tiku_assoc(tiku_assoc)
| 列名   | 类型   | KEY  | 可否为空 | 注释   |
| ---- | ---- | ---- | ---- | ---- |
|id|int8||是|null|
|catid|int8||是|null|
|tid|int8||是|null|
